module.exports = {
  src: [ '<%= sourcedir %>course/<%=languages%>/*.json' ]
}
